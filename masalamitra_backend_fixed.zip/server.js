const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());

app.get("/", (req, res) => {
  res.send("Backend is working!");
});

app.get("/masalas", (req, res) => {
  res.json([
    { name: "Haldi", price: 30 },
    { name: "Lal Mirch", price: 50 },
    { name: "Garam Masala", price: 70 }
  ]);
});

const port = process.env.PORT || 5000;
app.listen(port, () => {
  console.log(`✅ Server running on port ${port}`);
});